-- 2022.10.27

-- employees, departments

-- ���ι��
select employee_id, first_name, last_name, department_name
from employees e inner join departments d
on e.department_id = d.department_id
where e.department_id = 100;

-- ��������
select employee_id,first_name,last_name,department_id,
(
select department_name
from departments d
where e.department_id = d.department_id
)as dep_names

from employees e
where department_id = 100;

-- ���ν���(�Լ�)
create or replace function get_dep_name(dept_id number)
return varchar2

is
sDepName varchar2(30);

begin
select department_name
into sDepName
from departments
where department_id = dept_id;

return sDepName;

end;
/

variable var_depname varchar2(30);

exec :var_depname := get_dep_name(90);

print :var_depname;

select employee_id,first_name,last_name,get_dep_name(department_id)
from employees e
where e.department_id = 100;


-- emplyees jobs
-- ������̵�,�̸�,��,job_title

-- ���ι��
select employee_id, first_name, last_name,job_title
from employees e inner join jobs j
on e.job_id = j.job_id
where e.job_id = 'ST_CLERK';

-- ��������
select employee_id,first_name,last_name,job_id,
(
select job_id
from jobs j
where e.job_id = j.job_id
)as job_names

from employees e
where job_id = 'ST_CLERK';


-- get_job_title() �Լ�
create or replace function get_job_name(job_id number)
return varchar2

is
sDepName varchar2(30);

begin
select job_name
into sJobName
from jobs
where job_id = job_id;

return sJobName;

end;
/
























